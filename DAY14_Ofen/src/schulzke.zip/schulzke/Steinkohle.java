package schulzke;

public class Steinkohle extends Brennstoff{
	
	public Steinkohle() {
		super("Steinkohle", 55);
	}
	
}
