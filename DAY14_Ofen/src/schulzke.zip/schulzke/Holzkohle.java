package schulzke;

public class Holzkohle extends Brennstoff{
	
	public Holzkohle() {
		super("Holzkohle", 25);
	}

}
