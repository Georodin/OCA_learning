package schulzke;

public interface IBrennbar {
	public int brennt(Ofen ofen) throws InterruptedException;
}
