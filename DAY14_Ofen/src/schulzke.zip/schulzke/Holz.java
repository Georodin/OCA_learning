package schulzke;

public class Holz extends Brennstoff{

	public Holz() {
		super("Holz", 10);
	}
	
}
