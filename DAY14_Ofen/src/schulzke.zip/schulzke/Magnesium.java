package schulzke;

public class Magnesium extends Brennstoff{
	
	public Magnesium() {
		super("Magnesium", 350);
	}
	
}
