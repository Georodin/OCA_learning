package ml.schulzke.bauernhof.flora;

public class Gemuese {
	
	String sorte;
	public Gemuese(String sorte) {
		// TODO Auto-generated constructor stub
	}

	public String getSorte() {
		return sorte;
	}

	public void setSorte(String sorte) {
		this.sorte = sorte;
	}
	
}
