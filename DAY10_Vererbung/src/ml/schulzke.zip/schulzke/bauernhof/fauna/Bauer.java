package ml.schulzke.bauernhof.fauna;

public class Bauer extends Saeugetier{

}
