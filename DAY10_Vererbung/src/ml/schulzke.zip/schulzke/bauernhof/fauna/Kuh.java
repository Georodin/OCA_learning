package ml.schulzke.bauernhof.fauna;

public class Kuh extends Saeugetier{

}
