package ml.schulzke.bauernhof.fauna;

public class Saeugetier {

}
