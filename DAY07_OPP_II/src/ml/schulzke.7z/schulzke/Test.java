package ml.schulzke;

public class Test {

	public static void main(String[] args) {
		Dreieck d = new Dreieck();
		System.out.println (d.umfang(a, b, c)());
	}

}